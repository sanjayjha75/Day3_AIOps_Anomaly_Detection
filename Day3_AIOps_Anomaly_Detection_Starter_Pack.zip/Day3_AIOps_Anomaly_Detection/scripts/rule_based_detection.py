from pathlib import Path
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent.parent
INPUT_FILE = PROJECT_ROOT / "data" / "processed" / "server_metrics_clean.csv"
OUTPUT_FILE = PROJECT_ROOT / "data" / "processed" / "rule_based_results.csv"

# Illustrative training thresholds only; tune these using service context in real systems.
CPU_THRESHOLD = 90
MEMORY_THRESHOLD = 90
RESPONSE_TIME_THRESHOLD_MS = 1000
HTTP_5XX_THRESHOLD = 5


def main() -> None:
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"Dataset not found: {INPUT_FILE}")
    df = pd.read_csv(INPUT_FILE)
    required = {"timestamp", "host", "cpu_percent", "memory_percent", "response_time_ms", "http_5xx_count"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")
    if df.empty:
        raise ValueError("The dataset contains no observations.")

    df["rule_cpu"] = df["cpu_percent"] > CPU_THRESHOLD
    df["rule_memory"] = df["memory_percent"] > MEMORY_THRESHOLD
    df["rule_latency"] = df["response_time_ms"] > RESPONSE_TIME_THRESHOLD_MS
    df["rule_http_errors"] = df["http_5xx_count"] > HTTP_5XX_THRESHOLD
    rule_columns = ["rule_cpu", "rule_memory", "rule_latency", "rule_http_errors"]
    df["rule_anomaly"] = df[rule_columns].any(axis=1).astype(int)

    def explain_rules(row: pd.Series) -> str:
        reasons = []
        if row["rule_cpu"]:
            reasons.append(f"CPU > {CPU_THRESHOLD}%")
        if row["rule_memory"]:
            reasons.append(f"Memory > {MEMORY_THRESHOLD}%")
        if row["rule_latency"]:
            reasons.append(f"Response time > {RESPONSE_TIME_THRESHOLD_MS} ms")
        if row["rule_http_errors"]:
            reasons.append(f"HTTP 5xx count > {HTTP_5XX_THRESHOLD}")
        return "; ".join(reasons) if reasons else "No threshold exceeded"

    df["rule_reasons"] = df.apply(explain_rules, axis=1)
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUTPUT_FILE, index=False)

    flagged = df[df["rule_anomaly"] == 1]
    print("\nRULE-BASED ANOMALY DETECTION\n" + "=" * 45)
    print(f"Total observations: {len(df)}")
    print(f"Observations flagged: {len(flagged)}")
    print(f"Thresholds: CPU>{CPU_THRESHOLD}%, memory>{MEMORY_THRESHOLD}%, response time>{RESPONSE_TIME_THRESHOLD_MS} ms, HTTP 5xx>{HTTP_5XX_THRESHOLD}")
    if flagged.empty:
        print("No observations exceeded the configured thresholds.")
    else:
        print(flagged[["timestamp", "host", "cpu_percent", "memory_percent", "response_time_ms", "http_5xx_count", "rule_reasons"]].to_string(index=False))
    print(f"\nResults saved to: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
