from pathlib import Path
import matplotlib
matplotlib.use("Agg")  # Works in terminals without a graphical display.
import matplotlib.pyplot as plt
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent.parent
INPUT_FILE = PROJECT_ROOT / "data" / "processed" / "anomaly_comparison.csv"
OUTPUT_FILE = PROJECT_ROOT / "data" / "processed" / "anomaly_scatter.png"


def main() -> None:
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"Comparison file not found: {INPUT_FILE}\nRun compare_results.py first.")
    df = pd.read_csv(INPUT_FILE)
    required = {"cpu_percent", "response_time_ms", "rule_anomaly", "ml_anomaly"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"Comparison file is missing columns: {missing}")

    plt.figure(figsize=(10, 6))
    normal = df[(df["rule_anomaly"] == 0) & (df["ml_anomaly"] == 0)]
    both = df[(df["rule_anomaly"] == 1) & (df["ml_anomaly"] == 1)]
    rule_only = df[(df["rule_anomaly"] == 1) & (df["ml_anomaly"] == 0)]
    ml_only = df[(df["rule_anomaly"] == 0) & (df["ml_anomaly"] == 1)]

    plt.scatter(normal["cpu_percent"], normal["response_time_ms"], label="Neither flagged", alpha=0.75)
    plt.scatter(both["cpu_percent"], both["response_time_ms"], label="Both methods", marker="x", s=110)
    plt.scatter(rule_only["cpu_percent"], rule_only["response_time_ms"], label="Rules only", marker="s", s=80)
    plt.scatter(ml_only["cpu_percent"], ml_only["response_time_ms"], label="ML only", marker="^", s=85)
    plt.xlabel("CPU utilization (%)")
    plt.ylabel("Response time (ms)")
    plt.title("Operational metrics: rule-based vs. ML anomaly flags")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(OUTPUT_FILE, dpi=150)
    plt.close()
    print(f"Chart saved to: {OUTPUT_FILE}")
    print("Open the PNG in VS Code to inspect the flagged observations.")


if __name__ == "__main__":
    main()
