from pathlib import Path
import pandas as pd
from sklearn.ensemble import IsolationForest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
INPUT_FILE = PROJECT_ROOT / "data" / "processed" / "server_metrics_clean.csv"
OUTPUT_FILE = PROJECT_ROOT / "data" / "processed" / "ml_anomaly_results.csv"
FEATURE_COLUMNS = ["cpu_percent", "memory_percent", "response_time_ms", "http_5xx_count"]


def main() -> None:
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"Dataset not found: {INPUT_FILE}")
    df = pd.read_csv(INPUT_FILE)
    required = {"timestamp", "host", *FEATURE_COLUMNS}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")
    if len(df) < 10:
        raise ValueError("This introductory demonstration requires at least 10 observations.")
    features = df[FEATURE_COLUMNS].apply(pd.to_numeric, errors="coerce")
    if features.isna().any().any():
        raise ValueError("Model features contain missing/non-numeric values. Complete Day 2 preprocessing first.")

    # The anomaly_flag/reference label is deliberately NOT included as a feature.
    model = IsolationForest(n_estimators=100, contamination=0.15, random_state=42)
    model.fit(features)
    df["ml_prediction"] = model.predict(features)  # 1=normal, -1=anomaly
    df["ml_anomaly"] = (df["ml_prediction"] == -1).astype(int)  # 1=flagged, 0=not flagged
    df["ml_anomaly_score"] = model.decision_function(features)  # lower means more unusual
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUTPUT_FILE, index=False)

    flagged = df[df["ml_anomaly"] == 1]
    print("\nISOLATION FOREST ANOMALY DETECTION\n" + "=" * 45)
    print(f"Total observations: {len(df)}")
    print(f"Observations flagged by the model: {len(flagged)}")
    print("Parameters: n_estimators=100, contamination=0.15, random_state=42")
    if flagged.empty:
        print("No observations were flagged.")
    else:
        print(flagged[["timestamp", "host", *FEATURE_COLUMNS, "ml_anomaly_score"]].to_string(index=False))
    print(f"\nResults saved to: {OUTPUT_FILE}")
    print("Reminder: anomaly flags are investigation candidates, not proof of incidents.")


if __name__ == "__main__":
    main()
