from pathlib import Path
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent.parent
INPUT_FILE = PROJECT_ROOT / "data" / "processed" / "anomaly_comparison.csv"
OUTPUT_FILE = PROJECT_ROOT / "data" / "processed" / "anomaly_investigation_report.txt"


def main() -> None:
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"Comparison file not found: {INPUT_FILE}\nRun compare_results.py first.")
    df = pd.read_csv(INPUT_FILE)
    required = {"timestamp", "host", "cpu_percent", "memory_percent", "response_time_ms", "http_5xx_count", "rule_anomaly", "ml_anomaly", "reference_flag", "rule_and_ml", "rule_only", "ml_only", "investigation_reason"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"Comparison file is missing columns: {missing}")

    counts = {
        "Total observations analyzed": len(df),
        "Rule-based anomalies": int(df["rule_anomaly"].sum()),
        "Machine-learning anomalies": int(df["ml_anomaly"].sum()),
        "Flagged by both methods": int(df["rule_and_ml"].sum()),
        "Flagged only by rules": int(df["rule_only"].sum()),
        "Flagged only by machine learning": int(df["ml_only"].sum()),
    }
    report = ["AIOPS ANOMALY INVESTIGATION REPORT", "=" * 45, ""]
    report.extend(f"{key}: {value}" for key, value in counts.items())
    report.extend(["", "OBSERVATIONS REQUIRING INVESTIGATION", "-" * 45])
    flagged = df[(df["rule_anomaly"] == 1) | (df["ml_anomaly"] == 1)]
    if flagged.empty:
        report.append("No observations were flagged by either detector.")
    else:
        for _, row in flagged.iterrows():
            report.extend([
                f"Timestamp: {row['timestamp']}",
                f"Host: {row['host']}",
                f"CPU utilization: {row['cpu_percent']}%",
                f"Memory utilization: {row['memory_percent']}%",
                f"Response time: {row['response_time_ms']} ms",
                f"HTTP 5xx errors: {row['http_5xx_count']}",
                f"Rule-based flag: {int(row['rule_anomaly'])}",
                f"ML flag: {int(row['ml_anomaly'])}",
                f"Day 2 reference flag: {int(row['reference_flag'])}",
                f"Reason: {row['investigation_reason']}",
                "-" * 45,
            ])
    report.extend([
        "", "INTERPRETATION", "-" * 45,
        "Anomaly flags identify observations that deserve investigation.",
        "They do not prove that an incident occurred and do not identify root cause.",
        "Correlate findings with logs, traces, deployment events, workload context,",
        "and service objectives before making operational decisions.",
    ])
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_FILE.write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    print(f"\nReport saved to: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
