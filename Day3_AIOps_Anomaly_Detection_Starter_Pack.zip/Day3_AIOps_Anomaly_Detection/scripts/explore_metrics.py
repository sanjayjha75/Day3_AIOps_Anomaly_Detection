from pathlib import Path
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_FILE = PROJECT_ROOT / "data" / "processed" / "server_metrics_clean.csv"
NUMERIC_COLUMNS = ["cpu_percent", "memory_percent", "response_time_ms", "http_5xx_count"]


def main() -> None:
    if not DATA_FILE.exists():
        raise FileNotFoundError(
            f"Dataset not found: {DATA_FILE}\n"
            "Use the supplied starter ZIP or complete the Day 2 preprocessing lab first."
        )
    df = pd.read_csv(DATA_FILE)
    required = {"timestamp", "host", *NUMERIC_COLUMNS, "anomaly_flag"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")
    if df.empty:
        raise ValueError("The dataset contains no observations.")

    print("\nDATASET OVERVIEW\n" + "=" * 40)
    print(f"Total observations: {len(df)}")
    print(f"Unique hosts: {df['host'].nunique()}")
    print("\nFIRST FIVE OBSERVATIONS")
    print(df.head().to_string(index=False))
    print("\nDATA TYPES")
    print(df.dtypes)
    print("\nSUMMARY STATISTICS")
    print(df[NUMERIC_COLUMNS].describe().round(2))
    print("\nREFERENCE FLAGS FROM DAY 2")
    print(df["anomaly_flag"].value_counts().sort_index())
    print("\nCheckpoint: verify the file has 20 observations and 3 reference flags for the supplied sample.")


if __name__ == "__main__":
    main()
