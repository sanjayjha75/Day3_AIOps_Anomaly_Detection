from pathlib import Path
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent.parent
INPUT_FILE = PROJECT_ROOT / "data" / "processed" / "server_metrics_clean.csv"
RULE_FILE = PROJECT_ROOT / "data" / "processed" / "rule_based_results.csv"
ML_FILE = PROJECT_ROOT / "data" / "processed" / "ml_anomaly_results.csv"
OUTPUT_FILE = PROJECT_ROOT / "data" / "processed" / "anomaly_comparison.csv"
KEYS = ["timestamp", "host"]


def main() -> None:
    for path in (INPUT_FILE, RULE_FILE, ML_FILE):
        if not path.exists():
            raise FileNotFoundError(f"Required file not found: {path}\nRun the previous scripts in order.")
    original = pd.read_csv(INPUT_FILE)
    rules = pd.read_csv(RULE_FILE)
    ml_results = pd.read_csv(ML_FILE)
    for frame, name, columns in [
        (original, "original dataset", KEYS + ["cpu_percent", "memory_percent", "response_time_ms", "http_5xx_count", "anomaly_flag"]),
        (rules, "rule results", KEYS + ["rule_anomaly"]),
        (ml_results, "ML results", KEYS + ["ml_anomaly"]),
    ]:
        missing = sorted(set(columns) - set(frame.columns))
        if missing:
            raise ValueError(f"{name} is missing columns: {missing}")
        if frame.duplicated(KEYS).any():
            raise ValueError(f"{name} has duplicate timestamp/host keys; adjust the join keys for this dataset.")

    comparison = original[KEYS + ["cpu_percent", "memory_percent", "response_time_ms", "http_5xx_count", "anomaly_flag"]].copy()
    comparison = comparison.merge(rules[KEYS + ["rule_anomaly"]], on=KEYS, how="left", validate="one_to_one")
    comparison = comparison.merge(ml_results[KEYS + ["ml_anomaly"]], on=KEYS, how="left", validate="one_to_one")
    if comparison[["rule_anomaly", "ml_anomaly"]].isna().any().any():
        raise ValueError("Could not match every source observation across results. Check timestamp and host values.")
    comparison["rule_anomaly"] = comparison["rule_anomaly"].astype(int)
    comparison["ml_anomaly"] = comparison["ml_anomaly"].astype(int)
    comparison["reference_flag"] = comparison["anomaly_flag"].astype(int)
    comparison["rule_and_ml"] = ((comparison["rule_anomaly"] == 1) & (comparison["ml_anomaly"] == 1)).astype(int)
    comparison["rule_only"] = ((comparison["rule_anomaly"] == 1) & (comparison["ml_anomaly"] == 0)).astype(int)
    comparison["ml_only"] = ((comparison["rule_anomaly"] == 0) & (comparison["ml_anomaly"] == 1)).astype(int)
    comparison["investigation_reason"] = "Neither detector flagged this observation"
    comparison.loc[comparison["rule_and_ml"] == 1, "investigation_reason"] = "Flagged by both methods"
    comparison.loc[comparison["rule_only"] == 1, "investigation_reason"] = "Flagged by rule-based detection only"
    comparison.loc[comparison["ml_only"] == 1, "investigation_reason"] = "Flagged by machine learning only"

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    comparison.to_csv(OUTPUT_FILE, index=False)
    print("\nANOMALY DETECTION COMPARISON\n" + "=" * 45)
    print(f"Total observations: {len(comparison)}")
    print(f"Rule-based anomalies: {int(comparison['rule_anomaly'].sum())}")
    print(f"Machine-learning anomalies: {int(comparison['ml_anomaly'].sum())}")
    print(f"Flagged by both methods: {int(comparison['rule_and_ml'].sum())}")
    print(f"Flagged only by rules: {int(comparison['rule_only'].sum())}")
    print(f"Flagged only by machine learning: {int(comparison['ml_only'].sum())}")
    print("\nCOMPARISON DETAILS")
    print(comparison[KEYS + ["rule_anomaly", "ml_anomaly", "reference_flag", "investigation_reason"]].to_string(index=False))
    print(f"\nComparison saved to: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
