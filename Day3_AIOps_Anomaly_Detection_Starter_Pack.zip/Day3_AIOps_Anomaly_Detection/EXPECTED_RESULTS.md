# Expected Results and Self-Check

Use this page to check your results after running the scripts with the supplied synthetic dataset.

## Default settings
- Rows: 20
- Unique hosts: 1
- Reference flags from Day 2: 3
- Rule-based flags: 3
- Isolation Forest flags: 3
- Flagged by both: 3
- Rule-only: 0
- ML-only: 0
- Output chart: `data/processed/anomaly_scatter.png`
- Output report: `data/processed/anomaly_investigation_report.txt`

Both methods flag these timestamps in the supplied sample:
- 2026-10-20T09:30:00
- 2026-10-20T09:35:00
- 2026-10-20T09:40:00

## Optional stricter-threshold challenge
After changing thresholds to CPU >95%, memory >90%, response time >1000 ms, and HTTP 5xx >20:
- Rule-based flags: 1 (09:35 only)
- ML flags (existing model output): 3
- Flagged by both: 1
- Rule-only: 0
- ML-only: 2

## Important limitation
These counts describe the supplied synthetic sample only. Results can differ on other input data or software environments. The dataset is too small to make any production-accuracy claim.
